package ejercicios;

interface test_interface {
    void calcular();

    void logica(Float... a);
}
